import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

public class GuiMainWithFutureTask {

    /**
     * Launch the application.
     * @param args
     */
    public static void main(String[] args) {
        Display display = Display.getDefault();
        Shell shell = new Shell();
        shell.setSize(450, 300);
        shell.setText("SWT Application");

        Button btnLoadFile = new Button(shell, SWT.NONE);
        btnLoadFile.setBounds(10, 10, 100, 30);
        btnLoadFile.setText("Wait 10 Seconds");

        // Tạo ExecutorService
        ExecutorService executor = Executors.newSingleThreadExecutor();

        // Sự kiện nhấn nút
        btnLoadFile.addListener(SWT.Selection, event -> {
            // Tạo một FutureTask để chạy công việc bất đồng bộ
            FutureTask<String> futureTask = new FutureTask<>(new Callable<String>() {
                @Override
                public String call() throws Exception {
                    System.out.println("Processing in background...");
                    Thread.sleep(10000); // Giả lập công việc nặng trong 10 giây
                    return "Process completed!";
                }
            });

            // Thực thi FutureTask bằng Executor
            executor.submit(futureTask);

            // Kiểm tra kết quả của FutureTask mà không chặn UI thread
            Display.getDefault().asyncExec(() -> {
                // Sử dụng luồng riêng để kiểm tra xem FutureTask đã hoàn thành hay chưa
                new Thread(() -> {
                    try {
                        // Khi FutureTask hoàn thành, lấy kết quả
                        String result = futureTask.get();
                        // Cập nhật giao diện sau khi hoàn thành
                        Display.getDefault().asyncExec(() -> {
                            System.out.println(result);
                        });
                    } catch (InterruptedException | ExecutionException e) {
                        e.printStackTrace();
                    }
                }).start();
            });
        });

        shell.open();
        shell.layout();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }

        // Đóng ExecutorService khi kết thúc
        executor.shutdown();
    }
}
