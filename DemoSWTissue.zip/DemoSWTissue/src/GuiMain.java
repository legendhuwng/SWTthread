import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;

public class GuiMain {

    /**
     * Launch the application.
     * @param args
     */
    public static void main(String[] args) {
        Display display = Display.getDefault();
        Shell shell = new Shell();
        shell.setSize(450, 300);
        shell.setText("SWT Application");

        Button btnLoadFile = new Button(shell, SWT.NONE);
        btnLoadFile.setBounds(10, 10, 100, 30);
        btnLoadFile.setText("Wait 10 Seconds");

        // Sự kiện nhấn nút
        btnLoadFile.addListener(SWT.Selection, event -> {
            try {
                System.out.println("Processing...");
                // Giả lập xử lý công việc trong 10 giây ngay trên UI thread
                Thread.sleep(10000); // Treo giao diện trong 10 giây
                System.out.println("Process completed!");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        shell.open();
        shell.layout();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
    }
}
