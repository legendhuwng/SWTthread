import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.ProgressBar;

public class GuiMainWithThreadSolutionWithBar {

    /**
     * Launch the application.
     * @param args
     */
    public static void main(String[] args) {
        Display display = Display.getDefault();
        Shell shell = new Shell();
        shell.setSize(450, 300);
        shell.setText("SWT Application");

        // Tạo một nút để khởi động tiến trình
        Button btnLoadFile = new Button(shell, SWT.NONE);
        btnLoadFile.setBounds(10, 10, 100, 30);
        btnLoadFile.setText("Wait 10 Seconds");

        // Tạo thanh tiến trình
        ProgressBar progressBar = new ProgressBar(shell, SWT.INDETERMINATE);
        progressBar.setBounds(10, 50, 400, 20);
        progressBar.setVisible(false); // Ẩn thanh tiến trình ban đầu

        // Sự kiện nhấn nút
        btnLoadFile.addListener(SWT.Selection, event -> {
            // Hiển thị thanh tiến trình khi công việc bắt đầu
            progressBar.setVisible(true);

            // Tạo một luồng nền để xử lý công việc
            Thread thread = new Thread(() -> {
                try {
                    System.out.println("Processing in background...");
                    Thread.sleep(10000); // Giả lập công việc nặng trong 10 giây

                    // Cập nhật giao diện trên UI thread sau khi công việc hoàn tất
                    Display.getDefault().asyncExec(() -> {
                        System.out.println("Process completed!");
                        // Ẩn thanh tiến trình khi công việc kết thúc
                        progressBar.setVisible(false);
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            });

            // Bắt đầu luồng nền
            thread.start();
        });

        shell.open();
        shell.layout();
        while (!shell.isDisposed()) {
            if (!display.readAndDispatch()) {
                display.sleep();
            }
        }
    }
}
